Place your Lottie JSON files in this folder, e.g. loading.json. You can then import it with:

import loadingAnim from '@/assets/lottie/loading.json';

<LoadingLottie source={loadingAnim} />
