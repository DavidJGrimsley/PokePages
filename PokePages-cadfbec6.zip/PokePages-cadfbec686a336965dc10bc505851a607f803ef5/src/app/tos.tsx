import { DocumentPage } from "../components/DocumentPage";

export default function TOS() {
  return (
    <DocumentPage documentType="termsOfService" />
  );
}
