import { DocumentPage } from "../components/DocumentPage";

export default function PrivacyPolicy() {
  return (
    <DocumentPage documentType="privacyPolicy" />
  );
}
